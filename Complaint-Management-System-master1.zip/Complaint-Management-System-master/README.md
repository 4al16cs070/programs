
# Complaint Management System
## Overview
>This is the GitHub repository for the Complaint Management System.

This Application is Login based application. Ther are three type of users in this Application.
 * Admin
 * Engineers
 * Users

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

What things you need to install the software and how to install them

* php
* phpmyadmin 

```
     git clone https://github.com/Manashio/Complaint-Management-System.git
```


## Built With

* PHP 
* HTML
* CSS
* Bootstrap 
* JavaScript
* Jquery




## Authors

* **Manash Bharali** - *Initial work* - [github.Manashio](https://github.com/Manashio)

