<?php

    if(isset($_SESSION['name'])===false){
        header("location:../index.php");
    }

 ?>
