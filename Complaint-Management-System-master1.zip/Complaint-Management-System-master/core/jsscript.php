<script src="files/js/jquery.js"></script>
<script src="files/js/bootstrap.min.js"></script>
<script src="files/js/script.js"></script>
