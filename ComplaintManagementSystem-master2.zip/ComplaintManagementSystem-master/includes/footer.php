		<hr>
		<footer>
			<center>Copryright &copy; <?= date('Y'); ?></center>
		</footer>	
	</body>
</html>